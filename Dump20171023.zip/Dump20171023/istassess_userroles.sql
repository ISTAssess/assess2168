-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: istassess
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `userroles`
--

DROP TABLE IF EXISTS `userroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userroles` (
  `userId` varchar(15) NOT NULL,
  `roleId` varchar(15) NOT NULL,
  PRIMARY KEY (`userId`,`roleId`),
  KEY `FK_users_idx` (`userId`),
  KEY `FK_roles_idx` (`roleId`),
  CONSTRAINT `FK_UserRoles_Roles` FOREIGN KEY (`roleId`) REFERENCES `roles` (`roleId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_UserRoles_Users` FOREIGN KEY (`userId`) REFERENCES `users` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userroles`
--

LOCK TABLES `userroles` WRITE;
/*!40000 ALTER TABLE `userroles` DISABLE KEYS */;
INSERT INTO `userroles` VALUES ('aacics','Staff'),('aesfaa','CourseCoord'),('aesfaa','Faculty'),('amhgss','CourseCoord'),('amhgss','Faculty'),('aobics','Faculty'),('axgvks','Faculty'),('bdfvks','CourseCoord'),('bdfvks','Faculty'),('bhhics','CourseCoord'),('bhhics','Faculty'),('bmtski','CourseCoord'),('bmtski','Faculty'),('cbbics','CourseCoord'),('cbbics','Faculty'),('chairABC','DeptChair'),('chairXYZ','DeptChair'),('ciiics','CourseCoord'),('ciiics','Faculty'),('cxsics','Faculty'),('djpihst','CourseCoord'),('djpihst','Faculty'),('dlaics','CourseCoord'),('dlaics','Faculty'),('dmgics','Faculty'),('dmlics','CourseCoord'),('dmlics','Faculty'),('drkisd','CourseCoord'),('drkisd','Faculty'),('dsbics','CourseCoord'),('dsbics','Faculty'),('echics','Staff'),('efgics','CourseCoord'),('efgics','Faculty'),('emwics','CourseCoord'),('emwics','Faculty'),('ephics','CourseCoord'),('ephics','Faculty'),('gpavks','CourseCoord'),('gpavks','Faculty'),('hnkics','Faculty'),('jalics','CourseCoord'),('jalics','Faculty'),('jalvks','CourseCoord'),('jalvks','Faculty'),('jcjics','Faculty'),('jhsics','Staff'),('jmpics','Staff'),('jrhicsa','Faculty'),('jssics','Staff'),('jswics','Faculty'),('jwkics','CourseCoord'),('jwkics','Faculty'),('jxlics','Faculty'),('jxtadm','Faculty'),('kmsics','Faculty'),('krmics','Staff'),('ldrics','Faculty'),('lwb2627','Staff'),('lwhfac','CourseCoord'),('lwhfac','Faculty'),('Matt.Lake','Faculty'),('mayici','Faculty'),('mchics','Staff'),('mdl4959','Staff'),('mjcics','Faculty'),('mjcvks','Faculty'),('mjfics','AssessCoord'),('mjfics','CourseCoord'),('mjfics','Faculty'),('mjmics','CourseCoord'),('mjmics','Faculty'),('mphics','CourseCoord'),('mphics','Faculty'),('mrjics','Faculty'),('mxkics1','Faculty'),('nffbbu','Faculty'),('nxsvks','CourseCoord'),('nxsvks','Faculty'),('phlics','CourseCoord'),('phlics','Faculty'),('pxg5962','Staff'),('qyuvks','CourseCoord'),('qyuvks','Faculty'),('rdbcst','Staff'),('rpvvks','CourseCoord'),('rpvvks','Faculty'),('sarics','Faculty'),('sjzics','CourseCoord'),('sjzics','Faculty'),('spbics','Faculty'),('sphics','CourseCoord'),('sphics','Faculty'),('spmics','CourseCoord'),('spmics','Faculty'),('Staff','Staff'),('sxk5664','Staff'),('tapast','Staff'),('TBD','AssessCoord'),('thoics','CourseCoord'),('thoics','Faculty'),('tsbics','Faculty'),('txaics','Faculty'),('vlhics','CourseCoord'),('vlhics','Faculty');
/*!40000 ALTER TABLE `userroles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-23 10:35:36
